import java.io.File;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Demo {	
	
    public String baseUrl = "https://www.demoblaze.com/index.html";
    public WebDriver driver ; 
    WebDriverWait wait;
    String purchaseAmount;
    
	By laptopMenu = By.xpath("//a[text()='Laptops']");
	By sonyvaioi5 = By.xpath("//a[text()='Sony vaio i5']");
	By addToCart = By.xpath("//a[text()='Add to cart']");
	By home = By.xpath("//a[text()='Home ']");
	By delli78gb = By.xpath("//a[text()='Dell i7 8gb']");
	By cart = By.xpath("//a[text()='Cart']");
	By placeOrder = By.xpath("//button[text()='Place Order']");
	By purchase = By.xpath("//button[text()='Purchase']");
	By totalPrice = By.xpath("//h3[@id='totalp']");
	By orderDetail = By.xpath("//p[@class='lead text-muted ']");
	
	
	@BeforeSuite
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver","drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 15);
		driver.manage().window().maximize();
		driver.get(baseUrl);
		System.out.println(driver.getTitle());
	}
	
	@Test
	public void verifyOnlineShopping() throws InterruptedException{
		Actions builder = new Actions(driver);
		WebElement clickLaptopMenu = driver.findElement(laptopMenu);
		builder.moveToElement(clickLaptopMenu).click().build().perform();
		driver.findElement(sonyvaioi5).click();
		driver.findElement(addToCart).click();
		wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        alert.accept();
        builder.moveToElement(driver.findElement(home)).click().build().perform();
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(laptopMenu)));
        driver.findElement(laptopMenu).click();
        driver.findElement(delli78gb).click();
        driver.findElement(addToCart).click();
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert1 = driver.switchTo().alert();
        alert1.accept();
        builder.moveToElement(driver.findElement(cart)).click().build().perform();
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(totalPrice)));
        String totalAmount = driver.findElement(totalPrice).getText();
        System.out.println("totalAmount => "+totalAmount);
        driver.findElement(placeOrder).click();
        fillData();
        driver.findElement(purchase).click();
        takeScreenshot();
		String orderDetails = driver.findElement(orderDetail).getText();
		extractAmount(orderDetails);
		Assert.assertEquals(purchaseAmount,  totalAmount, "Amount is not equal");
	}

	@AfterSuite
	public void quitBrowser() {
		driver.close();
	}
	
	public void fillData() {
		driver.findElement(By.id("name")).sendKeys("abc");
        driver.findElement(By.id("country")).sendKeys("india");
        driver.findElement(By.id("city")).sendKeys("delhi");
        driver.findElement(By.id("card")).sendKeys("1234567890238476");
        driver.findElement(By.id("month")).sendKeys("02");
        driver.findElement(By.id("year")).sendKeys("2020");
	}
	
	public void takeScreenshot() {
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
        	FileHandler.copy(srcFile, new File("screenshot\\screenshot.png"));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public String extractAmount(String alertMessage) {
		System.out.println("str => "+alertMessage);
		String[] ss;
	    ss= alertMessage.split(":");
		System.out.println("ss[2] => "+ss[2]);
		String[] tempSs;
	    tempSs= ss[2].split(" ");
		System.out.println("tempSs[1] =>"+tempSs[1]+"<=");
		purchaseAmount = tempSs[1];
		return purchaseAmount;
	}
}
