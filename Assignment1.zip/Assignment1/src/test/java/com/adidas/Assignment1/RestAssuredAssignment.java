package com.adidas.Assignment1;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestAssuredAssignment {

	@Test(priority=1)
	public void GetListOfAvailablePets()
	{	
		RestAssured.baseURI = "https://petstore.swagger.io/v2/";
		RequestSpecification httpRequest = RestAssured.given();
		Response httpResponse = httpRequest.request(Method.GET, "pet/findByStatus?status=sold");
		String responseBody = httpResponse.getBody().asString();
		Assert.assertEquals(httpResponse.getStatusCode(), 200);
		Assert.assertEquals(httpResponse.getStatusLine(), "HTTP/1.1 200 OK");
	}


	@Test(priority=2)
	public void AddingANewPet()
	{	
		RestAssured.baseURI = "https://petstore.swagger.io/v2";
		RequestSpecification httpRequest = RestAssured.given();
		JSONObject obj=new JSONObject();
		obj.put("id", "9");
		obj.put("name", "Demo");
		obj.put("status", "available");
		httpRequest.header("Content-Type","application/json");
		httpRequest.body(obj.toJSONString());
		Response httpResponse = httpRequest.request(Method.POST, "/pet");
		String responseBody = httpResponse.getBody().asString();
		Assert.assertEquals(httpResponse.getStatusCode(), 200);
		Assert.assertEquals(httpResponse.getStatusLine(), "HTTP/1.1 200 OK");
	}

	@Test(priority=3)
  	public void UpdatingPetInfo()
  	{	 			
  		RestAssured.baseURI = "https://petstore.swagger.io/v2";
  		RequestSpecification httpRequest = RestAssured.given();
  		JSONObject obj=new JSONObject();
  		obj.put("id", "9");
  	    // Updating status from available to sold
  		obj.put("status", "sold");
  		httpRequest.header("Content-Type","application/json");
  		httpRequest.body(obj.toJSONString());
  		Response httpResponse = httpRequest.request(Method.PUT, "/pet");
  		String responseBody = httpResponse.getBody().asString();
  		Assert.assertEquals(httpResponse.getStatusCode(), 200);
  		Assert.assertEquals(httpResponse.getStatusLine(), "HTTP/1.1 200 OK");
  	}

	@Test(priority = 4)
	public void DeletingPetInfo() {

		RestAssured.baseURI = "https://petstore.swagger.io/v2";
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.header("Content-Type", "application/json");
		Response httpResponse = httpRequest.request(Method.DELETE, "/pet/9");
		String responseBody = httpResponse.getBody().asString();
		System.out.println(responseBody);
		int statusCode = httpResponse.getStatusCode();
		String statusLine = httpResponse.getStatusLine();
		Assert.assertEquals(statusCode, 200);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
	}
}
